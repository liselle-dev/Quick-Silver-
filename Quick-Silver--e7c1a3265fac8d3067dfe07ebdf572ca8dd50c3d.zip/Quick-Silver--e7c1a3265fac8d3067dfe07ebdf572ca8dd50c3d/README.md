# Quick-Silver-
QuickSilver is a mobile application designed to allow drivers to make immediate, fee-free toll payments when they forget their toll pass, use the wrong transponder, or forget to reload their transponder balance. The app detects toll usage in real time and allows drivers to pay instantly or shortly after passing through a toll, avoiding penalty fees
